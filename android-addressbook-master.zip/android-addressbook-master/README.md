Android Address Book replica with AngularJs
===========================================
CodePen: **[http://codepen.io/danielemoraschi/pen/deyos](http://codepen.io/danielemoraschi/pen/deyos)**

Touch scrolling by iScroll: **[http://cubiq.org/iscroll-4](http://cubiq.org/iscroll-4)** <br/>
Fake contacts list by: **[http://www.generatedata.com/](http://www.generatedata.com/)**

Best in Mobile / Chrome / Safari

Released under the MIT License:<br/>
**[http://www.opensource.org/licenses/mit-license.php](http://www.opensource.org/licenses/mit-license.php)**